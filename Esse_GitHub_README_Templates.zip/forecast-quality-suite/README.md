# 📊 Forecast Quality Suite

**Goal:** Provide a set of DAX metrics and Power BI templates for monitoring forecast accuracy and bias in supply chain or sales environments.

## 📐 Metrics Included
- **Forecast Accuracy (Row-Level):** `1 - ABS(Forecast - Actual)/Forecast`
- **Bias (% of Forecast):** `(Forecast - Actual)/Forecast`
- **Weighted Accuracy (WAPE):** `SUM(ABS(Forecast - Actual)) / SUM(Actual)`
- **Tracking Signal:** `Cumulative Forecast Error / MAD`

## 🧰 Components
- DAX formulas for Power BI
- Sample synthetic dataset (Actual vs Forecast)
- Visualization template (`Forecast_Dashboard.pbix`)

## 🎯 Business Impact
- Increased visibility into forecast error drivers
- Standardized KPI tracking across SKUs, plants, and customers
- Reduced reporting time from weeks to days
