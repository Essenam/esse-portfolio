# 🌍 Nuse — AI Platform for Financial Inclusion

**Goal:** Empower women entrepreneurs in emerging markets through voice-activated financial tracking and insights.

**Vision:** Democratize access to bookkeeping, lending, and education via natural language and low-connectivity tools.

## 💡 Core Features
- Voice-based transaction logging (WhatsApp integration)
- AI chatbot powered by GPT-4 prompt chains and LangChain
- NLP-driven insights & sentiment classification
- Integration with Google Sheets and Power BI dashboards

## 🧠 Tech Stack
Python · FastAPI · LangChain · OpenAI API · Google Sheets API · Power BI

## ⚙️ Prototype Architecture
1. User sends voice message → converted to text via Whisper
2. Intent classification via GPT-4
3. Data stored in Google Sheet → displayed in Power BI dashboard
4. Automated daily insights delivered via WhatsApp

**Outcome:** Simplified business management for micro-entrepreneurs and enabled financial institutions to assess creditworthiness faster.
