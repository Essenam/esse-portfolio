# 🛒 Cart-to-Purchase Analysis

**Goal:** Predict cart abandonment and identify factors driving drop-off rates to improve conversion and revenue recovery.

**Tech Stack:** Python (pandas, scikit-learn, matplotlib), Random Forest, Logistic Regression.

**Business Impact:** Achieved AUC = 0.993 and uncovered ~$239K in potential recovered revenue.

## 🔍 Project Overview
1. Data cleaning and preprocessing (930 records, 16 features)
2. Feature engineering on user session time, price, and category code
3. Model comparison: Logistic Regression · Decision Tree · Random Forest
4. Visualization and insights for product strategy

## 📈 Key Results
| Model | Accuracy | AUC | Comments |
|--------|-----------|-----|-----------|
| Logistic Regression | 0.95 | 0.97 | Baseline model |
| Decision Tree | 0.96 | 0.98 | Improved interpretability |
| Random Forest | **0.98** | **0.993** | Best-performing model |

**Notebook:** [`cart_to_purchase.ipynb`](./notebooks/cart_to_purchase.ipynb)

**Next Steps:** Deploy model as API endpoint for integration with BI tools.
